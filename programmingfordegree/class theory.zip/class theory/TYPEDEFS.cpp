#include <iostream>

//we have two ways of defining variables,
// which one is clearer?

// poor
float s, v, c; 

//more clear
typedef surface;
typedef volume;
typedef clear;

surface s;
volume v;
clear c;